<?php

namespace App\Http\models;

use Illuminate\Database\Eloquent\Model;

class Messages extends Model
{
    //
}

?>