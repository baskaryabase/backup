<?php

namespace App\Http\models;

use Illuminate\Database\Eloquent\Model;

class User_temps extends Model
{
    //
}

?>