 function getregistration(){
alert('fger');
 $('#register_modal').modal({ show: true });

}