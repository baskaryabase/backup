<?php

namespace App\Http\models;

use Illuminate\Database\Eloquent\Model;

class Users_company_details extends Model
{
    //
}

?>