<?php

namespace App\Http\models;

use Illuminate\Database\Eloquent\Model;

class Sc_memberpartner_logos extends Model
{
    //
}

?>