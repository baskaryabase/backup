<?php

namespace App\Http\models;

use Illuminate\Database\Eloquent\Model;

class Wp_users extends Model
{
    //
}


?>