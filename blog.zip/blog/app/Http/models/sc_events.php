<?php

namespace App\Http\models;

use Illuminate\Database\Eloquent\Model;

class Sc_events extends Model
{
    //
}

?>