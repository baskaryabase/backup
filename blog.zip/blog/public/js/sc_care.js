

$('.rsvp_link').click(function(){

  $('#total_amount').css('display','none');
$('#register_rsvp').attr('data-id',$(this).attr('data-id'));
$('#register_rsvp').attr('data-type',$(this).attr('data-type'));

$('#register_rsvp').text('Register');
$('.member_partner_display').css('display','none');

    

$('#rsvp_modal').modal({ show: true });


})

$('#register_rsvp').click(function(){

 $('#register_rsvp').prop('disabled', true);


var data_id =$(this).attr('data-id');
var demo_type=$(this).attr('data-type');


   var attendees_name=$('#attendees_name').val();
   var attendees_email=$('#attendees_email').val();
   var attendees_mobile=$('#attendees_mobile').val();
   var attendees_city=$('#attendees_city').val();
   var attendees_status=$('#attendees_status').val();
   var hidden_token=$('#hidden_token').val();

   var sam={
   	attendees_name:attendees_name,
   	attendees_email:attendees_email,
   	attendees_mobile:attendees_mobile,
   	attendees_city:attendees_city,
   	attendees_status:attendees_status,
   	data_id:data_id,
   	demo_type:demo_type,
   	_token:hidden_token,



   };

  jQuery.ajax({

                    url: '/CheckRsvp ',
                    type: 'POST',
                    data: sam,
                    cache: false,
                    success: function(data) {
                
                      $('#register_rsvp').prop('disabled', false);  
if(jQuery.trim(data.errors) != 'success'){

$('.wpcf7-not-valid-tip').html('');
                 $.each(data.errors, function(key,val) {

                                $('#'+key).after('<span class="wpcf7-not-valid-tip">'+val[0]+'<span>');

                            });


}else{
window.location.reload();
}
                    }

})
















})

