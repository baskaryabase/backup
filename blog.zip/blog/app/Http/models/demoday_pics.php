<?php

namespace App\Http\models;

use Illuminate\Database\Eloquent\Model;

class Demoday_pics extends Model
{
    //
}

?>