<?php

namespace App\Http\models;

use Illuminate\Database\Eloquent\Model;

class Speaker_metas extends Model
{
    //
}

?>